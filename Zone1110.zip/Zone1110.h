#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
extern NSString * const __kHashDefaultValue;
extern NSString * const __notificationTitle;
extern NSString * const __notificationTitlenoidung;
extern NSString * const __contact;
extern NSString * const __Confirm;
extern NSString * const __Input;
extern NSString * const __zone1110;
@interface Zone1110 : NSObject

extern NSString * const __kHashDefaultValue;
extern NSString * const __notificationTitle;
extern NSString * const __notificationTitlenoidung;
extern NSString * const __contact;
extern NSString * const __Confirm;
extern NSString * const __Input;
extern NSString * const __zone1110;
@end
