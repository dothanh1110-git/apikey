#import "Zone1110.h"
#import "encrypt.h"
#import <Foundation/Foundation.h>
NSString * const __kHashDefaultValue = NSSENCRYPT("mã token lấy ở web"); //token package
NSString * const __notificationTitle = NSSENCRYPT("Thông báo"); //Têu đề
NSString * const __notificationTitlenoidung = NSSENCRYPT("Xin chào"); //Nội dung 
NSString * const __contact = NSSENCRYPT("Liên hệ"); //Nội dung nút liên hệ
NSString * const __Confirm = NSSENCRYPT("Xác nhận"); //Nội dung nút xác nhận
NSString * const __Input = NSSENCRYPT("Nhập Key Ở Đây"); //Nội dung ô nhập
NSString * const __zone1110 = NSSENCRYPT("SERVER KEY by Zone1110"); //Nội dung ở ô thông báo xác thực thành công
//link liên hệ có thể đổi thành link vượt để gắn link kiếm tiền ở phần package trên server khi tạo package thì trên web có yêu cầu nhập link liên hệ thì đổi từ đó
